#Qa
SELECT COUNT(*) FROM table_info_sites WHERE nom_etablissement LIKE '%LYCEE%';


#Qb
SELECT nom_etablissement, conso_kWh_total
FROM table_factures
WHERE nom_etablissement LIKE '%LYCEE%' AND fluide LIKE '%Gaz%'
ORDER BY conso_kWh_total DESC FETCH FIRST 10 ROWS ONLY;

#Qd
SELECT nom_etablissement, conso_kWh_total
FROM table_factures
WHERE nom_etablissement LIKE '%LYCEE%' AND fluide LIKE '%ELECTRICITE%'
ORDER BY conso_kWh_total DESC FETCH FIRST 10 ROWS ONLY;

#Qf
SELECT nom_etablissement, conso_kWh_total
FROM table_factures
WHERE nom_etablissement LIKE '%LYCEE%' AND fluide LIKE '%Gaz%'
ORDER BY conso_kWh_total ASC FETCH FIRST 10 ROWS ONLY;

#Qg
SELECT nom_etablissement, conso_kWh_total
FROM table_factures
WHERE nom_etablissement LIKE '%LYCEE%' AND fluide LIKE '%ELECTRICITE%'
ORDER BY conso_kWh_total ASC FETCH FIRST 10 ROWS ONLY;



#Qh

SELECT f.nom_etablissement, s.type_site, SUM(f.conso_kWh_total) AS conso_totale
FROM table_factures f
JOIN table_info_sites s ON f.UAI = s.UAI
WHERE f.nom_etablissement LIKE '%LYCEE%' AND f.fluide LIKE '%Gaz%'
GROUP BY s.type_site, f.nom_etablissement
ORDER BY conso_totale ASC
FETCH FIRST 10 ROWS ONLY;

#Qi

SELECT f.nom_etablissement, s.type_site, SUM(f.conso_kWh_total) AS conso_totale
FROM table_factures f
JOIN table_info_sites s ON f.UAI = s.UAI
WHERE f.nom_etablissement LIKE '%LYCEE%' AND f.fluide LIKE '%ELECTRICITE%'
GROUP BY s.type_site, f.nom_etablissement
ORDER BY conso_totale ASC
FETCH FIRST 10 ROWS ONLY;


#Qj
SELECT nom_etablissement,
       (SELECT AVG(conso_kWh_total)
        FROM table_factures
        WHERE nom_etablissement = t.nom_etablissement AND fluide LIKE '%Gaz%') as Montant_moyen__gaz,
       (SELECT AVG(conso_kWh_total)
        FROM table_factures
        WHERE nom_etablissement = t.nom_etablissement AND fluide LIKE '%ELECTRICITE%') as Montant_moyen_electricite
FROM table_factures t
WHERE nom_etablissement LIKE '%LYCEE%' GROUP BY nom_etablissement;

#Qj


SELECT s.type_site,
       AVG(CASE WHEN f.fluide LIKE '%Gaz%' THEN f.conso_kWh_total ELSE 0 END) AS Montant_moyen_gaz,
       AVG(CASE WHEN f.fluide LIKE '%ELECTRICITE%' THEN f.conso_kWh_total ELSE 0 END) AS Montant_moyen_electricite
FROM table_factures f
JOIN table_info_sites s ON s.UAI = f.UAI
GROUP BY s.type_site;



#Qk

Select UAI
from table_info_sites
FULL OUTER JOIN
table_info_compteurs
ON table_info_sites.UAI = table_info_compteurs.UAI
WHERE table_info_sites.UAI IS NULL
OR table_info_compteurs.UAI IS NULL

//Selon cet requete tout est lié puisque il ne ressort rien en NULL

#Ql:
SELECT UAI, code_compteur
FROM table_info_compteurs
WHERE code_compteur IS NULL;
//Retourne rien car tout les compteurs sont associé à un UAI

Qm:
SELECT code_departement, COUNT(ID_du_site) as nombre_etablissements
FROM table_info_sites
GROUP BY code_departement;

Qn:
SELECT type_site, COUNT(ID_du_site) as nombre_etablissements
FROM table_info_sites
GROUP BY type_site;

Qo:
-- Select COUNT(date_facture)
-- from table_factures
--where date_facture BETWEEN TO_DATE('2021-01-01', 'YYYY-MM-DD') AND TO_DATE('2021-12-31', 'YYYY-MM-DD');
--


-- SELECT date_facture,
--        (SELECT COUNT(date_facture)
--         FROM table_factures
--         WHERE date_facture = t.date_facture AND date_facture BETWEEN TO_DATE('2021-01-01', 'YYYY-MM-DD') AND TO_DATE('2021-12-31', 'YYYY-MM-DD') AND
--         fluide LIKE '%Gaz%') as facture_gaz,
--        (SELECT COUNT(date_facture)
--         FROM table_factures
--         WHERE date_facture = t.date_facture AND date_facture BETWEEN TO_DATE('2021-01-01', 'YYYY-MM-DD') AND TO_DATE('2021-12-31', 'YYYY-MM-DD') AND
--         fluide LIKE '%ELECTRICITE%') as facture_ellectricite,
-- FROM table_factures t ;

SELECT date_facture,
       (SELECT COUNT(*)
        FROM table_factures
        WHERE date_facture = t.date_facture AND
              date_facture BETWEEN TO_DATE('2021-01-01', 'YYYY-MM-DD') AND TO_DATE('2021-12-31', 'YYYY-MM-DD') AND
              fluide LIKE '%Gaz%') as facture_gaz,
       (SELECT COUNT(*)
        FROM table_factures
        WHERE date_facture = t.date_facture AND
              date_facture BETWEEN TO_DATE('2021-01-01', 'YYYY-MM-DD') AND TO_DATE('2021-12-31', 'YYYY-MM-DD') AND
              fluide LIKE '%ELECTRICITE%') as facture_electricite
FROM table_factures t
WHERE date_facture BETWEEN TO_DATE('2021-01-01', 'YYYY-MM-DD') AND TO_DATE('2021-12-31', 'YYYY-MM-DD');


Qp :
SELECT fluide, AVG(facture_HTVA /  conso_kWh_total) as cout_moyen
FROM table_factures
WHERE date_facture BETWEEN TO_DATE('2020-01-01', 'YYYY-MM-DD') AND TO_DATE('2020-12-31', 'YYYY-MM-DD')
  AND conso_kWh_total IS NOT NULL
  AND facture_HTVA IS NOT NULL
  AND conso_kWh_total >0
  AND facture_HTVA >0
GROUP BY fluide;

Qq:
SELECT f.fluide, s.type_site, AVG(f.facture_HTVA / f.conso_kWh_total) as cout_moyen
FROM table_factures f
JOIN table_info_sites s ON f.UAI = s.UAI
WHERE f.date_facture BETWEEN TO_DATE('2021-01-01', 'YYYY-MM-DD') AND TO_DATE('2021-12-31', 'YYYY-MM-DD')
  AND f.conso_kWh_total IS NOT NULL
  AND f.facture_HTVA IS NOT NULL
  AND f.conso_kWh_total >0
  AND f.facture_HTVA >0
GROUP BY f.fluide, s.type_site ;





CREATE TABLE Electricite_table AS (
    SELECT UAI,
           ID_du_site,
           code_compteur,
           nom_compteur,
           fournisseur,
           date_debu_conso,
           date_fin_conso,
           facture_HTVA,
           facture_TTC
    FROM table_factures
    WHERE fluide = 'ELECTRICITE'
);

INSERT INTO Electricite_table (UAI, ID_du_site, code_compteur, nom_compteur, fournisseur, date_debu_conso, date_fin_conso, facture_HTVA, facture_TTC)
SELECT UAI, ID_du_site, code_compteur, nom_compteur, fournisseur, date_debu_conso, date_fin_conso, facture_HTVA, facture_TTC
FROM table_factures
WHERE fluide LIKE '%ELECTRICITE%';
